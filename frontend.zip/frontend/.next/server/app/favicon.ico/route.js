var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__a6d89067._.js")
R.c("server/chunks/[root-of-the-server]__c22bdfb2._.js")
R.c("server/chunks/frontend__next-internal_server_app_favicon_ico_route_actions_7d672445.js")
R.m(34117)
module.exports=R.m(34117).exports
