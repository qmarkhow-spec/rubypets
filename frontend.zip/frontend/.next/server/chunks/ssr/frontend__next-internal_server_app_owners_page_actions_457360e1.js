module.exports=[61762,(a,b,c)=>{}];

//# sourceMappingURL=frontend__next-internal_server_app_owners_page_actions_457360e1.js.map