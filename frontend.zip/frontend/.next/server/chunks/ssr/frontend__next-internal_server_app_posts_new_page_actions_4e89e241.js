module.exports=[2802,(a,b,c)=>{}];

//# sourceMappingURL=frontend__next-internal_server_app_posts_new_page_actions_4e89e241.js.map