module.exports=[50233,(a,b,c)=>{}];

//# sourceMappingURL=frontend__next-internal_server_app_debug_page_actions_01db802f.js.map