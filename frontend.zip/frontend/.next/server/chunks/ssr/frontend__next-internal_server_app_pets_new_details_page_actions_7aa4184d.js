module.exports=[17027,(a,b,c)=>{}];

//# sourceMappingURL=frontend__next-internal_server_app_pets_new_details_page_actions_7aa4184d.js.map