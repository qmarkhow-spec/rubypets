module.exports=[236,(a,b,c)=>{}];

//# sourceMappingURL=frontend__next-internal_server_app_register_page_actions_5040e2c7.js.map