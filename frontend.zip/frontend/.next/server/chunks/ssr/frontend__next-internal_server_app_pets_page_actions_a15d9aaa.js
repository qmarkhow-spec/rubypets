module.exports=[82511,(a,b,c)=>{}];

//# sourceMappingURL=frontend__next-internal_server_app_pets_page_actions_a15d9aaa.js.map