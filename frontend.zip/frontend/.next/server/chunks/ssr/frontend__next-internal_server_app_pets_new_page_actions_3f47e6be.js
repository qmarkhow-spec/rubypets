module.exports=[3719,(a,b,c)=>{}];

//# sourceMappingURL=frontend__next-internal_server_app_pets_new_page_actions_3f47e6be.js.map