module.exports=[84528,(a,b,c)=>{}];

//# sourceMappingURL=frontend__next-internal_server_app_search_page_actions_197bb7be.js.map