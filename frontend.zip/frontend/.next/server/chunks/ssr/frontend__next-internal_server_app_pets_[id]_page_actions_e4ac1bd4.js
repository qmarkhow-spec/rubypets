module.exports=[25524,(a,b,c)=>{}];

//# sourceMappingURL=frontend__next-internal_server_app_pets_%5Bid%5D_page_actions_e4ac1bd4.js.map