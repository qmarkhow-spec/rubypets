PRAGMA foreign_keys = ON;

ALTER TABLE pets ADD COLUMN class TEXT;
